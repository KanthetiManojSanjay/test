package com.order.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.order.dto.Order;
import com.order.model.OrderItem;
import com.order.service.OrderService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.Arrays;

import static com.order.constants.Constants.CUSTOMER_CREATE_SUCCESSFULLY;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest(controllers = OrderController.class)
class OrderControllerTests {

    @InjectMocks
    OrderController orderController;

    @MockBean
    OrderService orderService;

    @Autowired
    MockMvc mockMvc;

    ObjectMapper objectMapper = new ObjectMapper();
    private Order order;

    public void order(){
        order = Order.builder().customerName("Arun").orderDate("13/11/2020").shippingAddress("Hyderabad")
                .total(1035.25).orderItems(Arrays.asList(OrderItem.builder().productCode("C001").productName("Tracks").quantity(3).build())).build();
    }

    @BeforeEach
    public void setUp(){
        order();
    }


    @Test
    void createOrderTest() throws Exception {

        MvcResult mvcResult = this.mockMvc.perform(post("/createOrder")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(objectMapper.writeValueAsString(order))
        ).andExpect(status().isOk()).andReturn();

        String response=mvcResult.getResponse().getContentAsString();
        assertThat(response).isEqualTo(CUSTOMER_CREATE_SUCCESSFULLY);
    }

    @Test
    public void getOrderTest() throws Exception {

        Integer orderId=1;

        when(orderService.findOrder(orderId)).thenReturn(order);
        MvcResult mvcResult = this.mockMvc.perform(get("/fetchOrder")
                .param("orderId", String.valueOf(orderId))).andExpect(status().isOk()).andReturn();

        String response=mvcResult.getResponse().getContentAsString();
        Order responseOrder = objectMapper.readValue(response, Order.class);
        assertThat(responseOrder).isEqualTo(order);
    }

}
