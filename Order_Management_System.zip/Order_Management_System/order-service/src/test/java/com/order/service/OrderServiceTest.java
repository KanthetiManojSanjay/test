package com.order.service;

import com.order.dto.Order;
import com.order.exception.OrderNotFoundException;
import com.order.model.OrderItem;
import com.order.repository.OrderRepository;
import com.order.util.OrderClient;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;

import java.util.Arrays;
import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ContextConfiguration
public class OrderServiceTest {

    @InjectMocks
    OrderServiceImpl orderService;

    @Mock
    OrderRepository orderRepository;

    @Mock
    OrderClient orderClient;

    private Order order;
    private com.order.model.Order orderEO;
    private OrderItem orderItem;

    @BeforeEach
    public void SetUp() {
        MockitoAnnotations.initMocks(this);
        order = Order.builder().customerName("Arun").orderDate("13/11/2020").shippingAddress("Hyderabad")
                .total(1035.25).orderItems(Arrays.asList(OrderItem.builder().productCode("C001").productName("Tracks").quantity(3).build())).build();
        orderEO = com.order.model.Order.builder().customerName("Arun").shippingAddress("Hyderabad").orderDate(new Date(2020, 11, 13)).orderId(1).total(1035.25).build();
        orderItem = OrderItem.builder().orderItemId(1).productCode("C001").productName("Tracks").quantity(3).build();
    }

    @SneakyThrows
    @Test
    public void createOrderTest() {

        when(orderRepository.save(Mockito.any(com.order.model.Order.class))).thenReturn(orderEO);
        when(orderClient.createOrderItem(Mockito.any(OrderItem.class), Mockito.anyInt())).thenReturn(null);

        orderService.createOrder(order);
    }

    @Test
    public void findOrderTest() {

        // Given
        Integer orderId = 1;
        when(orderRepository.findByOrderId(orderId)).thenReturn(java.util.Optional.ofNullable(orderEO));
        when(orderClient.getOrderItems(orderId)).thenReturn(Arrays.asList(orderItem));

        // When
        Order order = orderService.findOrder(orderId);

        // Then
        assertThat(order).isEqualTo(order);
    }

    @Test
    public void findOrderTestNegative() {
        Integer orderId = 2;
        when(orderRepository.findByOrderId(orderId)).thenThrow(OrderNotFoundException.class);
        org.junit.jupiter.api.Assertions.assertThrows(OrderNotFoundException.class, ()-> orderService.findOrder(orderId));

    }
}
