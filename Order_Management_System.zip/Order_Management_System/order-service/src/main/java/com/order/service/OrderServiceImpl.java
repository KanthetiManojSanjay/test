package com.order.service;


import com.order.dto.Order;
import com.order.exception.OrderNotFoundException;
import com.order.model.OrderItem;
import com.order.repository.OrderRepository;
import com.order.util.OrderClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {

    @Autowired
    OrderRepository orderRepository;

    @Autowired
    OrderClient orderClient;

    @Override
    public void createOrder(Order order) throws ParseException {

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        com.order.model.Order orderEO = new com.order.model.Order();
        orderEO.setCustomerName(order.getCustomerName());
        orderEO.setOrderDate(sdf.parse(order.getOrderDate()));
        orderEO.setShippingAddress(order.getShippingAddress());
        orderEO.setTotal(order.getTotal());
        com.order.model.Order orderEntity = orderRepository.save(orderEO);
        order.getOrderItems().stream().forEach(o ->{
            orderClient.createOrderItem(o, orderEntity.getOrderId());
        });

    }

    @Override
    public Order findOrder(Integer orderId) {

        com.order.model.Order order = orderRepository.findByOrderId(orderId).orElseThrow(()->new OrderNotFoundException("Order Not found for Id:"+orderId));
        List<OrderItem> orderItemList = orderClient.getOrderItems(orderId);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Order orderDto = new Order();
        orderDto.setCustomerName(order.getCustomerName());
        orderDto.setOrderDate(sdf.format(order.getOrderDate()));
        orderDto.setOrderItems(orderItemList);
        orderDto.setShippingAddress(order.getShippingAddress());
        orderDto.setTotal(order.getTotal());
        return orderDto;

    }
}
