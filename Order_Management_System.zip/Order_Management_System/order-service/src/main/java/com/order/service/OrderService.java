package com.order.service;


import com.order.dto.Order;

import java.text.ParseException;

public interface OrderService {

    void createOrder(Order order) throws ParseException;

    Order findOrder(Integer orderId);
}
