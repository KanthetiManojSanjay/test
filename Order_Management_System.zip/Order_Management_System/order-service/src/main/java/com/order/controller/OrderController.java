package com.order.controller;


import com.order.dto.Order;
import com.order.service.OrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.text.ParseException;

import static com.order.constants.Constants.CUSTOMER_CREATE_SUCCESSFULLY;

@RestController
@Slf4j
public class OrderController {

    @Autowired
    OrderService orderService;

    @PostMapping("/createOrder")
    public String createOrder(@Valid @RequestBody Order order) {

        try {
            orderService.createOrder(order);
            return CUSTOMER_CREATE_SUCCESSFULLY;
        } catch (ParseException e) {
           log.error("Parsing error due to date: {}",e.getMessage());
        }
        return null;
    }

    @GetMapping("/fetchOrder")
    public Order getOrder(@RequestParam Integer orderId){
        return orderService.findOrder(orderId);
    }
}
