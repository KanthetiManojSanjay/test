package com.order.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Constants {
    public static final String CUSTOMER_CREATE_SUCCESSFULLY = "Customer created successfully";
    public static final String CUSTOMERNAME_CANNOT_BE_BLANK = "Customer name cannot be blank";
    public static final String ORDERDATE_CANNOT_BE_BLANK = "OrderDate name cannot be blank";
    public static final String SHIPPINGADDRESS_CANNOT_BE_BLANK = "Shipping Address cannot be blank";
    public static final String PRODUCTCODE_CANNOT_BE_BLANK = "Product code cannot be blank";
    public static final String PRODUCTNAME_CANNOT_BE_BLANK = "Product name cannot be blank";
    public static final String QUANTITY_SIZE_RESTRICTION = "Quantity cannot be less than 1";
}
