package com.order.dto;

import com.order.model.OrderItem;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

import static com.order.constants.Constants.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Order {

    @NotBlank(message = CUSTOMERNAME_CANNOT_BE_BLANK)
    private String customerName;
    @NotBlank(message = ORDERDATE_CANNOT_BE_BLANK)
    private String orderDate;
    @NotBlank(message = SHIPPINGADDRESS_CANNOT_BE_BLANK)
    private String shippingAddress;
    @Valid
    private List<OrderItem> orderItems;
    private double total;
}
