package com.order.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;

import static com.order.constants.Constants.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OrderItem {

    private Integer orderItemId;

    @NotBlank(message = PRODUCTCODE_CANNOT_BE_BLANK)
    private String productCode;

    @NotBlank(message = PRODUCTNAME_CANNOT_BE_BLANK)
    private String productName;

    @Range(min = 1, message = QUANTITY_SIZE_RESTRICTION)
    private Integer quantity;
}
