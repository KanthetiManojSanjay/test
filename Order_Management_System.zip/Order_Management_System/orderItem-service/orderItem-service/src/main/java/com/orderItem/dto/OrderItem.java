package com.orderItem.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OrderItem {

    private Integer orderItemId;
    private String productCode;
    private String productName;
    private Integer quantity;
}
