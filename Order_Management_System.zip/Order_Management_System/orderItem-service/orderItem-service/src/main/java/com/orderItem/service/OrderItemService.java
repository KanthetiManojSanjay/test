package com.orderItem.service;

import com.orderItem.dto.OrderItem;

import java.util.List;

public interface OrderItemService {

    OrderItem createOrderItem(OrderItem orderItem, Integer orderId);

    List<OrderItem> findOrderItems(Integer orderId);
}
