package com.orderItem.controller;


import com.orderItem.dto.OrderItem;
import com.orderItem.service.OrderItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class OrderItemController {

    @Autowired
    OrderItemService orderItemService;

    @PostMapping("/createOrderItem")
    public OrderItem createOrderItem(@RequestBody OrderItem orderItem,
                                     @RequestParam(required = false) Integer orderId) {
        return orderItemService.createOrderItem(orderItem, orderId);
    }

    @GetMapping("/fetchOrderItems")
    public List<OrderItem> getOrderItems(@RequestParam(required = false) Integer orderId) {
        return orderItemService.findOrderItems(orderId);
    }
}
