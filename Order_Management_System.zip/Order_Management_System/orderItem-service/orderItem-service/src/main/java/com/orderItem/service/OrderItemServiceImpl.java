package com.orderItem.service;

import com.orderItem.dto.OrderItem;
import com.orderItem.repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderItemServiceImpl implements OrderItemService {

    @Autowired
    OrderItemRepository orderItemRepository;

    @Override
    public OrderItem createOrderItem(OrderItem orderItem, Integer orderId) {
        com.orderItem.model.OrderItem orderItemEntity = new com.orderItem.model.OrderItem();
        orderItemEntity.setProductCode(orderItem.getProductCode());
        orderItemEntity.setProductName(orderItem.getProductName());
        orderItemEntity.setQuantity(orderItem.getQuantity());
        orderItemEntity.setOrderId(orderId);
        com.orderItem.model.OrderItem orderEO = orderItemRepository.save(orderItemEntity);
        orderItem.setOrderItemId(orderEO.getOrderItemId());
        return orderItem;
    }

    @Override
    public List<OrderItem> findOrderItems(Integer orderId) {
        List<com.orderItem.model.OrderItem> orderItemList = orderItemRepository.findByOrderId(orderId);
        List<OrderItem> orderItemDtoList = new ArrayList<>();
        orderItemList.stream().forEach(o -> {
            OrderItem orderItem = new OrderItem();
            orderItem.setOrderItemId(o.getOrderItemId());
            orderItem.setProductCode(o.getProductCode());
            orderItem.setProductName(o.getProductName());
            orderItem.setQuantity(o.getQuantity());
            orderItemDtoList.add(orderItem);
        });
        return orderItemDtoList;
    }
}
