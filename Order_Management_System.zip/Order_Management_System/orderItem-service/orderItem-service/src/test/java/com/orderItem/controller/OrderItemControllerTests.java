package com.orderItem.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.orderItem.dto.OrderItem;
import com.orderItem.service.OrderItemService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = OrderItemController.class)
public class OrderItemControllerTests {


	@InjectMocks
	OrderItemController orderItemController;

	@MockBean
	OrderItemService orderItemService;

	@Autowired
	MockMvc mockMvc;

	ObjectMapper objectMapper = new ObjectMapper();
	private OrderItem orderItem;

	public void orderItem(){
		orderItem = OrderItem.builder().productCode("C001").productName("Tracks").quantity(3).build();
	}

	@BeforeEach
	public void setUp(){
		orderItem();
	}


	@Test
	void createOrderItemTest() throws Exception {

		Integer orderId=1;
		when(orderItemService.createOrderItem(orderItem,orderId)).thenReturn(orderItem);

		MvcResult mvcResult = this.mockMvc.perform(post("/createOrderItem")
				.param("orderId", String.valueOf(orderId))
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(objectMapper.writeValueAsString(orderItem))
		).andExpect(status().isOk()).andReturn();

		String response=mvcResult.getResponse().getContentAsString();
		OrderItem responseOrderItem=objectMapper.readValue(response, OrderItem.class);
		assertThat(responseOrderItem.getProductCode()).isEqualTo("C001");
	}

	@Test
	public void getOrderTest() throws Exception {

		Integer orderId=1;

		when(orderItemService.findOrderItems(orderId)).thenReturn(Arrays.asList(orderItem));
		MvcResult mvcResult = this.mockMvc.perform(get("/fetchOrderItems")
				.param("orderId", String.valueOf(orderId))).andExpect(status().isOk()).andReturn();

		String response=mvcResult.getResponse().getContentAsString();
		List<OrderItem> responseOrderItemList = objectMapper.readValue(response, new TypeReference<List<OrderItem>>(){});
		assertEquals("C001",responseOrderItemList.get(0).getProductCode());
	}


}
