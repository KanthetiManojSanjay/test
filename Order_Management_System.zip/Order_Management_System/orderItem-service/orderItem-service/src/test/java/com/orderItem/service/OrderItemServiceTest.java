package com.orderItem.service;

import com.orderItem.dto.OrderItem;
import com.orderItem.repository.OrderItemRepository;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@ContextConfiguration
public class OrderItemServiceTest {

    @InjectMocks
    OrderItemServiceImpl orderItemService;

    @Mock
    OrderItemRepository orderItemRepository;

    private com.orderItem.model.OrderItem orderItemEO;
    private OrderItem orderItem;

    @BeforeEach
    public void SetUp() {
        MockitoAnnotations.initMocks(this);
        orderItemEO = com.orderItem.model.OrderItem.builder().orderItemId(1).orderId(1).productCode("C001").productName("Tracks").quantity(3).build();
        orderItem= OrderItem.builder().orderItemId(1).productCode("C001").productName("Tracks").quantity(3).build();
    }

    @SneakyThrows
    @Test
    public void createOrderItemTest() {

        Integer orderId=1;
        when(orderItemRepository.save(Mockito.any(com.orderItem.model.OrderItem.class))).thenReturn(orderItemEO);

        OrderItem orderItem = orderItemService.createOrderItem(this.orderItem, orderId);

    }

    @Test
    public void findOrderItemsTest() {

        Integer orderId=1;
        when(orderItemRepository.findByOrderId(orderId)).thenReturn(Arrays.asList(orderItemEO));

        List<OrderItem> orderItemsList = orderItemService.findOrderItems(orderId);

        assertEquals(orderItemsList.get(0).getProductCode(),"C001");
    }
}
